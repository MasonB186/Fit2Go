package com.example.mhatter.myfirstapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Launches CreatePlan
        Button createPlan = (Button)findViewById(R.id.CreatePlanBtn);
        createPlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), CreatePlan.class);

                startIntent.putExtra("com.example.mhatter.myfirstapp.SOMETHING1", "Create Plan");
                startActivity(startIntent);
            }
        });

        //Launches TrackProgress
        Button trackProgress = (Button)findViewById(R.id.TrackProgressBtn);
        trackProgress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), TrackProgress.class);

                startIntent.putExtra("com.example.mhatter.myfirstapp.SOMETHING2", "Track Progress");
                startActivity(startIntent);
            }
        });
        //Launches RemovePlan
        Button removePlan = (Button)findViewById(R.id.RemovePlanBtn);
        removePlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), RemovePlan.class);

                startIntent.putExtra("com.example.mhatter.myfirstapp.SOMETHING3", "Remove Plan");
                startActivity(startIntent);
            }
        });
        //Launches ClearHistory
        Button clearHistory = (Button)findViewById(R.id.ClearHistoryBtn);
        clearHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), ClearHistory.class);

                startIntent.putExtra("com.example.mhatter.myfirstapp.SOMETHING4", "Clear History");
                startActivity(startIntent);
            }
        });


        //Adds numbers inside of EditText and displays result in TextView
        Button addBtn = (Button) findViewById(R.id.addBtn);
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText firstNumEditText = (EditText) findViewById(R.id.firstNumEditText);
                EditText secondNumEditText = (EditText) findViewById(R.id.secondNumEditText);
                TextView resultTextView = (TextView) findViewById(R.id.resultTextView);

                int num1 = Integer.parseInt(firstNumEditText.getText().toString());
                int num2 = Integer.parseInt(secondNumEditText.getText().toString());
                int result = num1 + num2;
                resultTextView.setText(result + "");

            }
        });
    }
}
