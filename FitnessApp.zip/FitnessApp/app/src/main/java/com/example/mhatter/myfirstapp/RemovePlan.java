package com.example.mhatter.myfirstapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class RemovePlan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        if (getIntent().hasExtra("com.example.mhatter.myfirstapp.SOMETHING3")) {
            TextView tv = (TextView) findViewById(R.id.textView3);
            String text = getIntent().getExtras().getString("com.example.mhatter.myfirstapp.SOMETHING3");
            tv.setText(text);
        }


        Button mainActivity = (Button)findViewById(R.id.mainActivityBtn3);
        mainActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), MainActivity.class);

                startActivity(startIntent);
            }
        });
    }
}
