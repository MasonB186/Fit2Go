package com.Fit2Go;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.File;
import android.widget.*;


public class ConfirmProgress extends AppCompatActivity {




    private Button writeText, readText;
    private EditText enterText;
    private TextView showText;
    private String file = "myfile";
    private String fileContents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        writeText = findViewById(R.id.writeText);
        readText = findViewById(R.id.readText);
        enterText = findViewById(R.id.enterText);
        showText = findViewById(R.id.showText);



        String[] cRaces = getResources().getStringArray(R.array.races_array);

        showText.setText(cRaces[1]);

        writeText.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                fileContents = enterText.getText().toString();

                try{
                    FileOutputStream fOut = openFileOutput(file,MODE_PRIVATE);
                    fOut.write(fileContents.getBytes());
                    fOut.close();
                    File fileDir = new File(getFilesDir(),file);
                    Toast.makeText(getBaseContext(),"File Saved at " +fileDir, Toast.LENGTH_LONG);

                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        readText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                  FileInputStream fIn = openFileInput(file);
                  int c;
                  String temp = "";

                  while ((c = fIn.read()) != -1){

                      temp = temp + Character.toString((char)c);
                  }
                  showText.setText(temp);
                }
                catch (Exception e){

                    e.printStackTrace();
                }
            }
        });


        if (getIntent().hasExtra("com.Fit2Go.SOMETHING1")) {
            TextView tv = findViewById(R.id.textView);
            String text = getIntent().getExtras().getString("com.Fit2Go.SOMETHING1");
            tv.setText(text);
        }

        Button mainActivity = findViewById(R.id.mainActivityBtn);
        mainActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), MainActivity.class);

                startActivity(startIntent);
            }
        });
    }
}
