package com.Fit2Go;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class ChooseWorkout extends Activity {

    private Spinner spinner1, spinner2, spinner3;
    private Button btnSubmit, homeBtn;
    private String file1 = "file1", file2 = "file2", file3 = "file3";
    private String fileContents;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        addItemsOnSpinner1();
        addItemsOnSpinner2();
        addItemsOnSpinner3();
        addListenerOnButton();
    }

    // add items into spinner dynamically
    public void addItemsOnSpinner1() {

        spinner1 = (Spinner) findViewById(R.id.spinner1);
        List<String> list = new ArrayList<String>();
        list.add("1/2 mile");
        list.add("1 mile");
        list.add("2 miles");
        list.add("3 miles");
        list.add("6 miles");
        list.add("8 miles");
        list.add("10 miles");
        list.add("12 miles");
        list.add("16 miles");
        list.add("24 miles");


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(dataAdapter);
    }


    public void addItemsOnSpinner2() {

        spinner2 = (Spinner) findViewById(R.id.spinner2);
        List<String> list = new ArrayList<String>();
        list.add("10 Push-ups");
        list.add("20 Push-ups");
        list.add("30 Push-ups");
        list.add("40 Push-ups");
        list.add("50 Push-ups");
        list.add("60 Push-ups");
        list.add("70 Push-ups");
        list.add("80 Push-ups");
        list.add("90 Push-ups");
        list.add("100 Push-ups");


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter);
    }

    public void addItemsOnSpinner3() {

        spinner3 = (Spinner) findViewById(R.id.spinner3);
        List<String> list = new ArrayList<String>();
        list.add("10 Sit-ups");
        list.add("20 Sit-ups");
        list.add("30 Sit-ups");
        list.add("40 Sit-ups");
        list.add("50 Sit-ups");
        list.add("60 Sit-ups");
        list.add("70 Sit-ups");
        list.add("80 Sit-ups");
        list.add("90 Sit-ups");
        list.add("100 Sit-ups");


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(dataAdapter);
    }

    // get the selected dropdown list value
    public void addListenerOnButton() {

        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        spinner3 = (Spinner) findViewById(R.id.spinner3);


        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        homeBtn = (Button) findViewById(R.id.home);

        btnSubmit.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                Toast.makeText(ChooseWorkout.this,
                        "OnClickListener : " +
                                "\nSpinner 1 : "+ String.valueOf(spinner1.getSelectedItem()) +
                                "\nSpinner 2 : "+ String.valueOf(spinner2.getSelectedItem()) +
                                "\nSpinner 3 : "+ String.valueOf(spinner3.getSelectedItem()),

                        Toast.LENGTH_SHORT).show();





                fileContents = String.valueOf(spinner1.getSelectedItem());

                try{
                    FileOutputStream fOut = openFileOutput(file1,MODE_PRIVATE);
                    fOut.write(fileContents.getBytes());
                    fOut.close();
                    File fileDir = new File(getFilesDir(),file1);
                    Toast.makeText(getBaseContext(),"File Saved at " +fileDir, Toast.LENGTH_LONG);

                }
                catch (Exception e) {
                    e.printStackTrace();
                }

                fileContents = String.valueOf(spinner2.getSelectedItem());

                try{
                    FileOutputStream fOut = openFileOutput(file2,MODE_PRIVATE);
                    fOut.write(fileContents.getBytes());
                    fOut.close();
                    File fileDir = new File(getFilesDir(),file2);
                    Toast.makeText(getBaseContext(),"File Saved at " +fileDir, Toast.LENGTH_LONG);

                }
                catch (Exception e) {
                    e.printStackTrace();
                }

                fileContents = String.valueOf(spinner3.getSelectedItem());

                try{
                    FileOutputStream fOut = openFileOutput(file3,MODE_PRIVATE);
                    fOut.write(fileContents.getBytes());
                    fOut.close();
                    File fileDir = new File(getFilesDir(),file3);
                    Toast.makeText(getBaseContext(),"File Saved at " +fileDir, Toast.LENGTH_LONG);

                }
                catch (Exception e) {
                    e.printStackTrace();
                }

                Intent startIntent = new Intent(getApplicationContext(), MainActivity.class);

                startActivity(startIntent);
            }

        });

        homeBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent startIntent = new Intent(getApplicationContext(), MainActivity.class);

                startActivity(startIntent);
            }
        });
    }
}
