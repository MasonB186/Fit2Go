package com.Fit2Go;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.FileInputStream;

public class MainActivity extends AppCompatActivity {

    private String file1 = "file1", file2 = "file2", file3 = "file3";
    private TextView showText1, showText2, showText3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        showText1 = findViewById(R.id.textView8);
        showText2 = findViewById(R.id.textView9);
        showText3 = findViewById(R.id.textView10);


        //Launches ConfirmProgress
        Button confirmProgress = (Button)findViewById(R.id.ConfirmProgressBtn);
        confirmProgress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), ConfirmProgress.class);

                startActivity(startIntent);
            }
        });

        //Launches ChooseWorkout
        Button chooseWorkout = (Button)findViewById(R.id.ChooseWorkoutBtn);
        chooseWorkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), ChooseWorkout.class);

                startActivity(startIntent);
            }
        });


        try {
            FileInputStream fIn = openFileInput(file1);
            int c;
            String temp = "";

            while ((c = fIn.read()) != -1){

                temp = temp + Character.toString((char)c);
            }
            showText1.setText(temp);
        }
        catch (Exception e){

            e.printStackTrace();
        }

        try {
            FileInputStream fIn = openFileInput(file2);
            int c;
            String temp = "";

            while ((c = fIn.read()) != -1){

                temp = temp + Character.toString((char)c);
            }
            showText2.setText(temp);
        }
        catch (Exception e){

            e.printStackTrace();
        }

        try {
            FileInputStream fIn = openFileInput(file3);
            int c;
            String temp = "";

            while ((c = fIn.read()) != -1){

                temp = temp + Character.toString((char)c);
            }
            showText3.setText(temp);
        }
        catch (Exception e){

            e.printStackTrace();
        }

    }
}
